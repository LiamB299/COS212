public class ListNode {

    public Integer key;
    public Integer data = -1;
    
    // End of list is indicated with null
    public ListNode next = null;

    public ListNode(Integer key) {
        this.key = key;
    }
}